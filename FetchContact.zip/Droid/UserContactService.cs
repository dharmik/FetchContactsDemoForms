﻿using System;
namespace FetchContactsDemo.Droid
{
	public class UserContactService
	{
		public UserContactService()
		{
		}
	}
}
